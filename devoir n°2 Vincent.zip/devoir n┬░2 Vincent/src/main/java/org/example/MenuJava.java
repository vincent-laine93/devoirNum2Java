import java.util.Scanner;
import java.util.Random;

public class MenuJava
{
    // Exercice n°1
    // NE PAS EFFACER
    static int[] tabFrequence = new int[11];
    static String[] tabEntetes = new String[]{"2","3","4","5","6","7","8","9","10","11","12"};

    // Exercice n°2
    // NE PAS EFFACER
    static int[][] tableau1Exo2 = new int[][]{{1,2,4},{5,6,7},{2,1,3}};
    static int[][] tableau2Exo2 = new int[][]{{2,2,4},{1,3,5},{1,4,8}};
    static int[][] tableauProduitExo2 = new int[3][3];
    public static void main(String[] args)
    {
        int choix;
        Scanner scanner = new Scanner(System.in);
        do
        {
            do
            {
                System.out.println("1 - Exercice 1");
                System.out.println("2 - Exercice 2");
                System.out.println("0 - Quitter");
                System.out.print("Votre choix : ");
                choix = scanner.nextInt();
            } while (choix > 4);

            switch (choix)
            {
                case 0:
                    System.out.println("Fin du programme");
                    break;
                case 1:
                    /* renitialisation du tableau a 0 car a chaque fois que je relancer le programme
                     les ancienne valeur ete conserver */

                    for (int i = 0; i < tabFrequence.length; i++){
                        tabFrequence[i] = 0;
                    }

                    // déclaration des variables

                    Random random = new Random();
                    int dee1;
                    int dee2;
                    int sommeDee;
                    int frequenceMax = 0;

                    // remplissage du tableau des frequences
                    for (int i = 0; i < 20; i++){
                        dee1 = random.nextInt(6)+1;
                        dee2 = random.nextInt(6)+1;
                        sommeDee = dee1 + dee2;
                        switch (sommeDee){
                            case 2:
                                tabFrequence[0] ++;
                                break;
                            case 3:
                                tabFrequence[1] ++;
                                break;
                            case 4:
                                tabFrequence[2] ++;
                                break;
                            case 5:
                                tabFrequence[3] ++;
                                break;
                            case 6:
                                tabFrequence[4] ++;
                                break;
                            case 7:
                                tabFrequence[5] ++;
                                break;
                            case 8:
                                tabFrequence[6] ++;
                                break;
                            case 9:
                                tabFrequence[7] ++;
                                break;
                            case 10:
                                tabFrequence[8] ++;
                                break;
                            case 11:
                                tabFrequence[9] ++;
                                break;
                            case 12:
                                tabFrequence[10] ++;
                                break;
                        }
                    }
                    // trouver la valeur maximum de la fréquence
                    for (int i = 0; i < tabFrequence.length; i++){
                        if (tabFrequence[i]> frequenceMax){
                            frequenceMax = tabFrequence[i];
                        }
                    }
                     // déclaration du tableau tabLignes + initialisation a 0 car valeur null

                    String[][] tabLignes = new String[frequenceMax + 1][11];

                    for (int i = 0; i < tabLignes.length; i++){
                        for (int j = 0; j < tabLignes[i].length; j++){
                            tabLignes[i][j] = " ";
                        }
                    }

                    //remplissage du tableau tabLignes

                    for (int i = 0; i < 11; i++){
                      tabLignes[frequenceMax][i] = Integer.toString(tabFrequence[i]);
                    }

                    for (int i = 0; i < 11; i++){
                        if (tabFrequence[i]  != 0){
                            for (int j = tabFrequence[i] -1; j >= 0; j--){
                                tabLignes[j][i] = "*";
                            }
                        }
                    }

                    // Affichage final

                    for (int i = 0; i < 11; i++){
                        System.out.print(tabEntetes[i] + "\t");
                    }
                    System.out.println();

                    for (int i = 0; i <= frequenceMax; i++){
                        for (int j = 0; j < 11; j++){
                            System.out.print(tabLignes[i][j] + "\t");
                        }
                        System.out.println();
                    }

                    break;
                case 2:
                    // remplissage du tableau

                    for (int i = 0; i < 3; i++) {
                        for (int j = 0; j < 3; j++) {
                            for (int k = 0; k < 3; k++) {
                                tableauProduitExo2[i][j] += tableau1Exo2[i][k] * tableau2Exo2[k][j];
                            }
                        }
                    }

                    //Affichage du tableau
                    for (int i = 0; i < 3; i++) {
                        for (int j = 0; j < 3; j++) {
                            System.out.print(tableauProduitExo2[i][j] + "\t");
                        }
                        System.out.println();
                    }

                    break;
            }
        }while (choix != 0);
    }
}
